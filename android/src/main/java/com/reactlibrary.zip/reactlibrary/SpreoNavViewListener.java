package com.reactlibrary;

public interface SpreoNavViewListener {
    String calculateDistance();
}
