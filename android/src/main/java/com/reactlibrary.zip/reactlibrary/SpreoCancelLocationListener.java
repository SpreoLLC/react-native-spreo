package com.reactlibrary;

public interface SpreoCancelLocationListener {
    void locationCalculationCanceled();
}
