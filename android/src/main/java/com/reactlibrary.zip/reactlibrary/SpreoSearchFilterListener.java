package com.reactlibrary;

public interface SpreoSearchFilterListener {
    void onFilterResultPublished();
}
