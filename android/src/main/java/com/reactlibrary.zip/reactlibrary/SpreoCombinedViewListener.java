package com.reactlibrary;

public interface SpreoCombinedViewListener {
    void onTitleChanged(String title);
    void onActionRequested(String action);
    void onCampusSelectionClick();
}
