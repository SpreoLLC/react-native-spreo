package com.reactlibrary;


import com.mlins.utils.GalleryObject;

public class SpreoCoverFlowData {

    public GalleryObject galleryObject;
    public String url;

    public SpreoCoverFlowData(GalleryObject bitmap, String url) {
        this.galleryObject = bitmap;
        this.url = url;
    }
}
