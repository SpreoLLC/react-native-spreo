package com.reactlibrary;

public enum SpreoSearchItem {
    POI,
    FAVORITE,
    HISTORY,
    CATEGORY;
}
