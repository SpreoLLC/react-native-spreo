package com.reactlibrary;

public class SpreoNewFloorObject {
    final int floorId;
    final String floorText;

    public SpreoNewFloorObject(int floorId, String floorText) {
        this.floorId = floorId;
        this.floorText = floorText;
    }


}
