package spreo.spreomobile;

public interface SpreoOnUserDataDownloadedCallBack {
    public void OnUserDataDownloaded(String status);
}