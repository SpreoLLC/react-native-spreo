package com.reactlibrary;

public enum SpreoSettingsRequestState {
    LOCATION,
    FROM_TO,
    PARKING;
}
