package com.reactlibrary;

public interface SpreoUpdateListener {
    void OnUpdateFinished();
}
