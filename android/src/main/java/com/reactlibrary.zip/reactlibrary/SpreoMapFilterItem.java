package com.reactlibrary;


public class SpreoMapFilterItem {

    public String name;
    boolean isChecked;

    public SpreoMapFilterItem(String name, boolean isChecked) {
        this.name = name;
        this.isChecked = isChecked;
    }
}
