package com.reactlibrary;

public interface MapFilterListener {
    void mapFilterApplied();
}
